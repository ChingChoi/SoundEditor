﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoundEditorOptimize
{
    /// <summary>
    /// Manages all wav file objects
    /// </summary>
    class AudioFileManager
    {
        ArrayList audioFiles;

        /// <summary>
        /// Constructor of AudioFileManager
        /// </summary>
        public AudioFileManager()
        {
            AudioFiles = new ArrayList();
        }

        public ArrayList AudioFiles { get => audioFiles; set => audioFiles = value; }
    }
}
